# Heart-Disease-Prediction
A project that predicts whether a person is suffering from heart disease or not.
